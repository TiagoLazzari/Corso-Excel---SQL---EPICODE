create database ToysGroup;

use ToysGroup;

CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(255)
);

ALTER TABLE Product
ADD COLUMN CategoryID INT,
ADD CONSTRAINT fk_category
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID);

CREATE TABLE Sales (
    SaleID INT PRIMARY KEY auto_increment,
    ProductID INT,
    SaleDate DATE,
    SaleAmount DECIMAL(10 , 2 ),
    RegionID INT,
    FOREIGN KEY (ProductID)
        REFERENCES Product (ProductID),
    FOREIGN KEY (RegionID)
        REFERENCES Region (RegionID)
);


CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(255)
);

CREATE TABLE Category (
    CategoryID INT PRIMARY KEY,
    CategoryName VARCHAR(255)
);

INSERT INTO Category (CategoryID, CategoryName)
VALUES
    (1, 'Giocattoli per Bambini'),
    (2, 'Puzzle e Giochi da Tavolo'),
    (3, 'Peluches e Bambole'),
    (4, 'Modellismo e Costruzioni'),
    (5, 'Giochi Educativi'),
    (6, 'Giochi Musicali'),
    (7, 'Giochi Creativi');

INSERT INTO Product (ProductID, ProductName, CategoryID)
VALUES
    (1, 'Macchinina Telecomandata', 1),
    (2, 'Bambola di Pezza', 3),
    (3, 'Set di Costruzioni', 4),
    (4, 'Puzzle a Incastro', 2),
    (5, 'Peluche Orsacchiotto', 3),
    (6, 'Kit Pittura per Bambini', 5),
    (7, 'Robot Interattivo', 1),
    (8, 'Cucina in Miniatura', 7),
    (9, 'Gioco da Tavolo', 2),
    (10, 'Pista da Corsa', 1),
    (11, 'Modellino di Aereo', 4),
    (12, 'Kit Scientifico', 5),
    (13, 'Kit di Gioielli Fai-da-te', 6),
    (14, 'Set di Accessori per Bambole', 3),
    (15, 'Cavallo a Dondolo', 1),
    (16, 'Cubetto Didattico', 5),
    (17, 'Treno in Legno', 4),
    (18, 'Strumenti Musicali per Bambini', 6),
    (19, 'Kit di Animali in Peluche', 3),
    (20, 'Kit per Costruire Astronavi in Carta', 4);
    
    INSERT INTO Region (RegionID, RegionName)
VALUES
    (1, 'Austria'),
    (2, 'Belgio'),
    (3, 'Bulgaria'),
    (4, 'Cipro'),
    (5, 'Croazia'),
    (6, 'Danimarca'),
    (7, 'Estonia'),
    (8, 'Finlandia'),
    (9, 'Francia'),
    (10, 'Germania'),
    (11, 'Grecia'),
    (12, 'Irlanda'),
    (13, 'Italia'),
    (14, 'Lettonia'),
    (15, 'Lituania'),
    (16, 'Lussemburgo'),
    (17, 'Malta'),
    (18, 'Paesi Bassi'),
    (19, 'Polonia'),
    (20, 'Portogallo'),
    (21, 'Repubblica Ceca'),
    (22, 'Romania'),
    (23, 'Slovacchia'),
    (24, 'Slovenia'),
    (25, 'Spagna'),
    (26, 'Svezia'),
    (27, 'Ungheria');
    
    INSERT INTO Sales (ProductID, SaleDate, SaleAmount, RegionID)
VALUES
    (7, '2024-01-14', 36.72, 12),
    (19, '2024-01-21', 65.49, 24),
    (9, '2024-02-03', 24.13, 15),
    (6, '2024-01-17', 73.11, 8),
    (13, '2024-01-20', 19.07, 4),
    (15, '2024-02-11', 83.39, 15),
    (6, '2024-01-19', 34.22, 18),
    (17, '2024-02-10', 22.45, 7),
    (15, '2024-02-17', 91.06, 11),
    (1, '2024-01-11', 76.68, 23),
    (18, '2024-03-13', 69.74, 14),
    (6, '2024-03-06', 97.33, 26),
    (15, '2024-02-07', 94.63, 18),
    (17, '2024-02-21', 51.92, 11),
    (7, '2024-01-29', 85.27, 20),
    (11, '2024-01-16', 61.65, 22),
    (9, '2024-03-21', 10.53, 17),
    (16, '2024-01-12', 28.24, 24),
    (8, '2024-01-21', 83.25, 1),
    (7, '2024-02-11', 57.23, 12),
    (9, '2024-01-18', 49.16, 14),
    (12, '2024-03-02', 62.92, 11),
    (17, '2024-01-29', 98.21, 3),
    (10, '2024-02-02', 61.29, 22),
    (13, '2024-02-12', 31.71, 12),
    (6, '2024-02-11', 42.08, 20),
    (6, '2024-01-16', 67.93, 16),
    (7, '2024-01-15', 92.84, 14),
    (5, '2024-02-23', 80.31, 20),
    (13, '2024-02-02', 37.57, 23),
    (3, '2024-01-07', 94.42, 18),
    (3, '2024-02-05', 44.83, 13),
    (20, '2024-03-03', 93.08, 17),
    (2, '2024-01-09', 73.32, 6),
    (8, '2024-01-20', 28.96, 7),
    (12, '2024-02-03', 29.24, 15),
    (17, '2024-01-30', 72.37, 8),
    (20, '2024-01-19', 59.39, 24),
    (20, '2024-03-02', 25.89, 19),
    (12, '2024-02-13', 45.82, 11);
    
-- 1)Verificare che i campi definiti come PK siano univoci. 
-- Prodotti
SELECT 
    COUNT(*) AS TotaleProdotti
FROM
    Product;
-- Regioni
SELECT 
    COUNT(*) AS TotaleRegioni
FROM
    region;
-- Categorie
SELECT 
    COUNT(*) AS TotaleCategorie
FROM
    category;
-- Sales
SELECT 
    COUNT(*) AS TotaleVendite
FROM
    sales;
-- 2)Esporre l'elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  
SELECT 
    p.ProductName,
    YEAR(s.SaleDate) AS AnnoVendita,
    SUM(s.SaleAmount) AS FatturatoTotale
FROM
    Product p
        JOIN
    Sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductName , YEAR(s.SaleDate)
order by FatturatoTotale desc;

-- 3)Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT 
    r.RegionName,
    YEAR(s.SaleDate) AS AnnoVendita,
    SUM(s.SaleAmount) AS FatturatoTotale
FROM
    Region r
        JOIN
    Sales s ON r.RegionID = s.RegionID
GROUP BY r.RegionName , YEAR(s.SaleDate)
ORDER BY YEAR(s.SaleDate) , FatturatoTotale DESC;

-- 4)Qual è la categoria di articoli maggiormente richiesta dal mercato? 
SELECT 
    c.CategoryName, COUNT(p.ProductID) AS TotaleProdotti
FROM
    Category c
        JOIN
    Product p ON c.CategoryID = p.CategoryID
GROUP BY c.CategoryName
ORDER BY TotaleProdotti DESC;
-- LIMIT 1;

-- 5)Quali sono, se ci sono, i prodotti invenduti? , caso 1
SELECT 
    ProductID, ProductName
FROM
    Product
WHERE
    ProductID NOT IN (SELECT DISTINCT
            ProductID
        FROM
            Sales);
            
-- 5)Quali sono, se ci sono, i prodotti invenduti? , caso 2
SELECT 
    p.ProductID, p.ProductName
FROM
    Product p
        LEFT JOIN
    Sales s ON p.ProductID = s.ProductID
WHERE
    s.SaleID IS NULL;
    
-- 6)Esporre l'elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT 
    p.ProductName, MAX(s.SaleDate) AS DataUltimaVendita
FROM
    Product p
        JOIN
    Sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductName
order by DataUltimaVendita desc;